import java.util.Scanner;
import java.util.Arrays;

public class DrugaGrupa {
	
	// Zadaci sa nizovima
	// Prvi zadatak 
	/*
	public static void main(String[] args) {
		Scanner unos = new Scanner(System.in);
		System.out.println("Unesite duzinu niza");
		int n = unos.nextInt();
		int[] niz = new int[n];
		System.out.println("Unesite elemente niza");
		for(int i=0;i<n;i++) {
			niz[i]=unos.nextInt();
		}
		int brojac=0;
		for(int i=0;i<n;i++) {
			if(niz[i]>0) {
				brojac++;
			}
		}
		System.out.println("Broj pozitivnih brojeva u nizu je:"+brojac);
	}
	 */
	
	// Drugi zadatak
	/*
	public static void main(String[] args) {
		Scanner unos = new Scanner(System.in);
		System.out.println("Unesite duzinu niza");
		int n = unos.nextInt();
		int[] niz = new int[n];
		System.out.println("Unesite elemente niza");
		for(int i=0; i<n;i++) {
			niz[i] = unos.nextInt();
		}
		int brojac=0;
		for(int i=0;i<n;i++) {
			if(niz[i]<0 && niz[i]%2==0) {
				brojac++;
			}
		}
		int[] nizNegativni = new int[brojac];
		int j=0;
		for(int i=0;i<n;i++) {
			if(niz[i]<0 && niz[i]%2==0) {
				nizNegativni[j]=niz[i];
				j++;
			}
		}
	System.out.println("Niz negativnih parnih brojeva iz datog niza je: ");
	 for(int k=0;k<brojac;k++) {
		System.out.println(nizNegativni[k]);
	}
	}
	 */
	
	// Treci zadatak
	/*
	public static void main(String[] args) {
		Scanner unos = new Scanner(System.in);
		System.out.println("Unesite duzinu niza");
		int n = unos.nextInt();
		int[] a = new int[n];
		System.out.println("Unesite elemente niza");
		for(int i=0; i<n;i++) {
			a[i] = unos.nextInt();
		}
		System.out.println("Unesite parametar x");
		int x = unos.nextInt();
		for(int i=0; i<n;i++) {
			if(a[i]%2==0) {
				a[i]=a[i]+x;
			}
		}
	}
	*/
	
	// Cetvrti zadatak
	/*
	public static void main(String[] args) {
		int[] niz =  {5, 1, 2, 3, 0, 1, 5, 0, 2};
		int suma = 0;
		for(int i=0;i<niz.length;i++) {
			if(niz[i]!=0) {
				suma+=niz[i];
			}
			else 
				break;
		}
		System.out.println("Zbir brojeva koje je djecak sabrao je "+suma);
	}
	*/
	
	// Peti zadatak
	/*
	public static void main(String[] args) {
		int[] niz= {-2, 7, -5, 3, 1, -4};
		int suma=0;
		for(int i=0;i<niz.length;i++) {
			if(niz[i]<0 && niz[i]%2==0) {
				suma+=niz[i]*(-1);
			}
		}
		System.out.println("Apsolutna vrijednost sume negativnih parnih brojeva niza je "+suma);
	}
	*/
	
	// Sesti zadatak
	/*
	public static void main(String[] args) {
		int[] niz = {1,2,3};
		int max = 3;
		int manji=0;
		for(int i=0; i<niz.length;i++) {
			if(niz[i]<max) {
				manji++;
			}
		}
		System.out.println("Broj elemenata niza koji su manji od "+max+" je "+manji);
	}
	*/
	
	// Sedmi zadatak
	/*
	public static void main(String[] args) {
		Scanner unos = new Scanner(System.in);
		System.out.println("Unesite broj proizvoda");
		int n = unos.nextInt();
		double[] niz = new double[n];
		System.out.println("Unesite cijene proizvoda");
		double zarada=0;
		for(int i=0;i<n;i++) {
			niz[i]=unos.nextDouble();
			zarada+=niz[i];
		}
		// Ako uzmemo da se u procentima smanji cijena svih proizvoda;
		double zarada2=0;
		for(int i=0;i<n;i++) {
			niz[i]=niz[i]*0.9; // npr. smanjene su sve cijene za 10%
			zarada2+=niz[i];
		}
		System.out.println("Nakon snizavanja cijena, vlasnik ima zaradu manju za"+(zarada-zarada2));
	}
	*/
	
	// Osmi zadatak
	/*
	public static void main(String[] args) {
		Scanner unos = new Scanner(System.in);
		System.out.println("Unesite broj zaposlenih");
		int n = unos.nextInt();
		double[] niz = new double[n];
		System.out.println("Unesite plate zaposlenih");
		for(int i=0;i<n;i++) {
			niz[i]=unos.nextDouble();
		}
		double max=niz[0];
		double max2=0;
		for(int i=1;i<n;i++) {
			if(niz[i]>max)
				max2=max;
				max=niz[i];
		}
		System.out.println("Druga najveca plata u kolektivu iznosi "+max2);
	}
	*/
	
	// Deveti zadatak
	/*
	public static void main(String[] args) {
		Scanner unos = new Scanner(System.in);
		System.out.println("Unesite duzinu prvog niza");
		int x = unos.nextInt();
		int[] niz1 = new int[x];
		System.out.println("Unesite duzinu drugog niza");
		int y = unos.nextInt();
		int[] niz2= new int[y];
		System.out.println("Unesite elemente prvog niza");
		for(int i=0;i<x;i++) {
			niz1[i]=unos.nextInt();
		}
		System.out.println("Unesi elemente drugog niza");
		for(int i=0;i<y;i++) {
			niz2[i]=unos.nextInt();
		}
		// Provjeravamo koliko ima zajednickih brojeva
		int j = 0;
		int brojac =0;
		for(int i=0;i<x;i++) {
			while(j!=y) {
				if(niz1[i]==niz2[j]) {
					brojac++;
					j=0;
					break;
				}
				else {
					j++;
				}
			}
			j=0;
		}
		int k=0;
		int[] niz3 = new int[brojac];
		for(int i = 0; i < x; i++) {
            for(int m = 0; m < y; m++) {
                if(niz1[i] == niz2[m]) {
                    niz3[k] = niz1[i];
                    k++;
                    break; 
                }
	}
		}
		System.out.println("Niz zajednickih brojeva je: ");
		for(int m=0;m<brojac;m++) {
			System.out.println(niz3[m]);
		}
	}
	*/
	
	// Deseti zadatak
	/*
	public static void main(String[] args) {
		Scanner unos = new Scanner(System.in);
		System.out.println("Unesite duzinu niza");
		int x = unos.nextInt();
		int[] niz = new int[x];
		System.out.println("Unesite elemente niza");
		for(int i=0;i<x;i++) {
			niz[i]=unos.nextInt();
		}
		int brojac=0;
		for(int i=0;i<x;i++) {
			for(int j=i+1;j<x;j++) {
				if(niz[i]==niz[j]*(-1)) {
					brojac++;
					break;
				}
			}
		}
		System.out.println("Ukupan broj trazenih elemenata je "+brojac);
	}
	*/
	
	// Jedanaesti zadatak
	/*
	public static void main(String[] args) {
		Scanner unos = new Scanner(System.in);
		System.out.println("Unesite duzinu niza brojeva");
		int n = unos.nextInt();
		int[] niz = new int[n];
		System.out.println("Unesite elemente niza");
		for(int i=0;i<n;i++) {
			niz[i]=unos.nextInt();
		}
		int max=0;
		int maxBroj=0;
		int trenutno=0;
		double trenutniBroj=0;
		for(int i=0;i<n;i++) {
			if(niz[i]<0) {
				trenutniBroj= niz[i]*(-1);
			while(trenutniBroj>0) {
				trenutno+=trenutniBroj%10;
				trenutniBroj=trenutniBroj/10;
			}
			if(trenutno>max) {
				max=trenutno;
			    maxBroj=niz[i];
			    }
			trenutno=0;
			trenutniBroj=0;
			}
			else {
				trenutniBroj=niz[i];
				while(trenutniBroj>0) {
					trenutno+=trenutniBroj%10;
					trenutniBroj=trenutniBroj/10;
				}
				if(trenutno>max) {
					max=trenutno;
				    trenutno=0;
				    maxBroj=niz[i];
				  	}
				trenutniBroj=0;
				trenutno=0;
			}
		System.out.println("Broj sa najvecom sumom cifara u nizu je "+maxBroj);
		}
	}
	*/
	
	// Dvanaesti zadatak
	/*
	public static int stepen(int a) {
		int duzina=0;
		int temp=a;
		if(a==0)
			return 1;
		if(a<0) {
			a=a*(-1);
			while(temp!=0) {
				temp=a/10;
				duzina++;
				temp=temp/10;
			}
		}
		else {
			while(temp!=0) {
				temp=a/10;
				duzina++;
			}
		}
		return duzina;
	}
	
	public static void main(String[] args) {
		Scanner unos = new Scanner(System.in);
		System.out.println("Unesite duzinu niza");
		int n = unos.nextInt();
		int[] niz = new int[n];
		System.out.println("Unesite elemente niza");
		for(int i=0;i<n;i++) {
			niz[i]=unos.nextInt();
		}
		double suma=0;
		int tempBroj=0;
		int brojac=0;
		int stepenBroja=0;
		for(int i=0;i<n;i++) {
		tempBroj = niz[i] < 0 ? -niz[i] : niz[i];
		stepenBroja=stepen(niz[i]);
		while(tempBroj!=0) {
			suma+=Math.pow((tempBroj%10),stepenBroja);
			tempBroj=tempBroj/10;
		}
		if(suma==niz[i]) {
			brojac++;
		}
		suma=0;
		tempBroj=0;
		}
		System.out.println("Broj brojeva koji su Narcistic je "+brojac);
	}
	*/
	
	// Trinaesti zadatak
	/*
	public static int[] longest_increasing(int[] input_array) {
     if (input_array==null || input_array.length==0) {
    	 return new int [0];
     }
     int maxDuzina=0;
     int trenutnaDuzina=0;
     int startPoz=0;
     int krajnjaPoz=0;
     int maxStart=0;
     int maxKraj=0;
     for(int i=0;i<input_array.length;i++) {
    	 if(input_array[i]>0) {
    	 if(trenutnaDuzina==0 || input_array[i]<=input_array[i+1]) {
    		 if(trenutnaDuzina==0) {
    			 startPoz=i;
    		 }
    		 trenutnaDuzina++;
    	 }
    	 else {
    	 if(trenutnaDuzina>maxDuzina) {
    		 maxDuzina=trenutnaDuzina;
    		 maxStart=startPoz;
    		 maxKraj=i-1;
    	 }
    	 startPoz=i;
    	 trenutnaDuzina=0;
     }
    	 }
    	 else {
    		 if(trenutnaDuzina>maxDuzina) {
        		 maxDuzina=trenutnaDuzina;
        		 maxStart=startPoz;
        		 maxKraj=krajnjaPoz-1;
        	 }
        	 trenutnaDuzina=0;
         }
    	 }
     if(trenutnaDuzina>maxDuzina) {
    	 maxDuzina=trenutnaDuzina;
    	 maxKraj=input_array.length-1;
    	 maxStart=startPoz;
     }
	return Arrays.copyOfRange(input_array,maxStart,maxKraj+1);
}
	public static void main(String[] args) {
		int[] input_array = {1, 2, 3, -1, 0, 5, 6, 7, 10, 10, 1};
		int[] rezultat = longest_increasing(input_array);
		System.out.println("Trazeni najveci rastuci podniz pozitivnih brojeva je "+ Arrays.toString(rezultat));
		}
	}
	*/
	
	// Cetrnaesti zadatak
	/*
	public static void main(String[] args) {
		int[] niz = {1,2,3,4,5,6,7,8,9,10};
		int[] obrnut = new int[niz.length];
		int j=niz.length-1;
		for(int i=0;i<niz.length;i++) {
			obrnut[j]=niz[i];
			j--;
		}
		System.out.println("Niz sa obrnutim redosljedom je ");
		for(int i=0;i<10;i++) {
			System.out.println(obrnut[i]);
		}
		}
}
*/
	
	// Petnaesti zadatak
	/*
	public static void main(String[] args) {
		Scanner unos = new Scanner(System.in);
		System.out.println("Unesite duzinu niza");
		int n = unos.nextInt();
		int[] niz = new int[n];
		System.out.println("Unesite elemente niza");
		for(int i=0;i<n;i++) {
			niz[i]=unos.nextInt();
		}
		int minElement=niz[0];
		int minIndeks=0;
		int suma=niz[0];
		for(int i=1;i<n;i++) {
			suma+=niz[i];
			if(niz[i]<minElement) {
				minElement=niz[i];
				minIndeks=i;
			}
		}
		double prosjek = suma/n;
		System.out.println("Prosjecna ocjena na ispitu je"+prosjek);
		System.out.println("Najmanji broj bodova na ispitu je ostvario student sa indeksom "+minIndeks+" a broj bodova je "+minElement);
	}
}
*/
	
	// Sesnaesti zadatak
	
	public static void main(String[] args) {
		Scanner unos = new Scanner(System.in);
		int n = 10;
		System.out.println("Unesite broj posjeta na poslednjih 10 utakmica");
		int max=0;
		int[] niz = new int[n];
		for(int i=0;i<n;i++) {
			niz[i] = unos.nextInt();
			if(niz[i]>max) {
				max=niz[i];
			}
		}
		System.out.println("Najveci broj posjeta u jednom danu je "+max);
	}
}

