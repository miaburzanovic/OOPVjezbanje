import java.util.ArrayList;

public class TestnaKlasaAuto {
	
	public static void main(String[] main) {
		Auto a1 = new Auto("bmw",2010,2000,false,2000,true);
		Auto a2 = new Auto("mercedes",2015,2000,false,2000,false);
		Auto a3 = new Auto("lada",1985,2000,false,2000,false);
		Auto a4 = new Auto("vw",2025,2000,false,2000,false);
		Auto a5 = new Auto("fiat",2009,2000,false,2000,true);
		Auto a6 = new Auto("audi",2015,2000,false,2000,false);
		ArrayList<Auto> listaAuta = new ArrayList<>();
		listaAuta.add(a1);
		listaAuta.add(a2);
		listaAuta.add(a3);
		listaAuta.add(a4);
		listaAuta.add(a5);
		listaAuta.add(a6);
		a1.ispisi();
		a2.ispisi();
		a3.ispisi();
		a4.ispisi();
		a5.ispisi();
		a6.ispisi();
		double iznos = Auto.iznosRegistracije(listaAuta);
		System.out.println("Iznos registracije za sve automobile koji se mogu registrovati sumirano je "+iznos);
		ArrayList<Auto> mogucnost = Auto.mogucnostRegistracije(listaAuta);
		System.out.println("Lista auta koja se mogu registrovati:");
		for(Auto a : mogucnost) {
			System.out.println(a.getMarkaAuta()+" "+a.getGodisteAuta());
		}
	}

}
