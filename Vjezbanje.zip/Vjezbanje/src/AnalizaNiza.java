
public class AnalizaNiza {
	
	public static double nadjiParniProsjek(int[] niz) {
		double suma=0.0;
		int brojac=0;
		for(int i=0;i<niz.length;i++) {
			if(niz[i]%2==0 && niz[i]>0) {
				suma+=niz[i];
				brojac++;
			}
		}
		double prosjek = suma/brojac;
		return prosjek;
	}

}
