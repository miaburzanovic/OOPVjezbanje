
public class BankovniRacun {
	private String imeVlasnika;
	private double stanje;
	
	public BankovniRacun(String imeVlasnika, double stanje) {
		this.imeVlasnika = imeVlasnika;
		this.stanje = stanje;
	}
	public String getImeVlasnika() {
		return imeVlasnika;
	}
	public void setImeVlasnika(String imeVlasnika) {
		if(imeVlasnika!=null)
		this.imeVlasnika = imeVlasnika;
	}
	public double getStanje() {
		return stanje;
	}
	public void setStanje(double stanje) {
		this.stanje = stanje;
	}
	
	public void uplati(double iznos) {
		this.stanje=stanje+iznos;
	}
	public void isplati(double iznos) {
		if(this.stanje>=iznos) {
			this.stanje=stanje-iznos;
		}
		else
			System.out.println("Na bankovnom racunu nema dovoljno sredstava");
	}
	
	public void ispisi() {
		System.out.println("Bankovni racun klijenta "+this.imeVlasnika+" ima stanje od "+this.stanje);
	}
	
}
