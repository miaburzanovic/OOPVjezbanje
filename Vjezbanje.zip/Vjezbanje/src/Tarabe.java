import java.util.ArrayList;

public class Tarabe {
	
	public static String izdvojTarabe (String log) {
		
		if(log == null || log.isEmpty()) {
			return "";
		}
		
		String[] izdvoj = log.split(",");
		ArrayList<String> hesteg = new ArrayList<>();
		
		for(String a:izdvoj) {
			a=a.trim();
			if(a.startsWith("#")) {
				boolean provjera = false;
				
				for(String h : hesteg) {
					
					if(h.equalsIgnoreCase(a)){
						provjera = true;
						break;
					}
					
					if(provjera ==  false) {
						hesteg.add(a);
					}
				}
			}
		}
		
		hesteg.sort(String.CASE_INSENSITIVE_ORDER);
		return String.join(",", hesteg);
		
	}

}
