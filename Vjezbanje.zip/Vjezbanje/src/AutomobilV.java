
public class AutomobilV extends Vozilo {
	private int brojVrata;
	private int brojOsoba;
	
	public AutomobilV() {
		this.setMarka(null);
		this.setModel(null);
		this.setKubikaza(0);
		this.setGodiste(1945);
		brojVrata = 0;
		brojOsoba = 0;
	}
	
	public AutomobilV(String marka, String model, int kubikaza, int godiste, int brojVrata, int brojOsoba) {
		super(marka, model, kubikaza, godiste);
		this.brojVrata = brojVrata;
		this.brojOsoba = brojOsoba;
	}
	public int getBrojVrata() {
		return brojVrata;
	}
	public void setBrojVrata(int brojVrata) {
		this.brojVrata = brojVrata;
	}
	public int getBrojOsoba() {
		return brojOsoba;
	}
	public void setBrojOsoba(int brojOsoba) {
		this.brojOsoba = brojOsoba;
	}
	@Override
	public String toString() {
		return "Automobil - broj vrata: " + brojVrata + ", broj osoba: " + brojOsoba + ", marka: " + getMarka()
				+ ", model: " + getModel() + ", kubikaza: " + getKubikaza() + ", godiste: " + getGodiste();
	}
	
	@Override
	
	public float iznosRegistracije() {
		float iznos = (this.getKubikaza()/10 +(2026-this.getGodiste())*10)*Vozilo.getOsnovicaZaRegistraciju();
		return iznos;
	}
	

}
