import java.util.ArrayList;

public class TestnaKlasa {
	public static void main(String[] args) {
		StudentPred s1 = new StudentPred("Marko","Markovic","25/001","Skopska",55,true);
		StudentPred s2 = new StudentPred("Maja","Markovic","25/002","Slobode",20,true);
		StudentPred s3 = new StudentPred("Marko","Petrovic","25/055","Skopska",80,true);
		StudentPred s4 = new StudentPred("Matija","Jovanovic","25/088","Jaglinke Adzic",87,true);
		ArrayList<StudentPred> lista = new ArrayList<>();
		lista.add(s1);
		lista.add(s2);
		lista.add(s3);
		lista.add(s4);
		System.out.println("Studenti koji zive u ulici Skopska: ");
		ArrayList<StudentPred> istaUlica = StudentPred.komsije(lista, "Skopska");
		for(StudentPred a : istaUlica) {
			System.out.println(a.getIme()+" "+a.getPrezime());
		}
		System.out.println("Studenti koji su polozili ispit: ");
		ArrayList<StudentPred> polozenIspit = StudentPred.poloziliIspit(lista, 50);
		for(StudentPred a: polozenIspit) {
			System.out.println(a.getIme()+" "+a.getPrezime()+" sa brojem bodova "+a.getBrojBodova());
		}
	}

}
