
public class Vozilo {
	private String marka;
	private String model;
	private int kubikaza;
	private int godiste;
	private static float osnovicaZaRegistraciju;
	
	public Vozilo() {
		marka = "";
		model = "";
		kubikaza = 0;
		godiste = 1945;
	}
	
	
	public Vozilo(String marka, String model, int kubikaza, int godiste) {
		this.marka = marka;
		this.model = model;
		this.kubikaza = kubikaza;
		this.godiste = godiste;
	}
	
	public String getMarka() {
		return marka;
	}
	public void setMarka(String marka) {
		if(marka!=null)
		this.marka = marka;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		if(model!=null)
		this.model = model;
	}
	public int getKubikaza() {
		return kubikaza;
	}
	public void setKubikaza(int kubikaza) {
		if(kubikaza>=0)
		this.kubikaza = kubikaza;
	}
	public int getGodiste() {
		return godiste;
	}
	public void setGodiste(int godiste) {
		if(godiste>=1945)
		this.godiste = godiste;
	}
	public static float getOsnovicaZaRegistraciju() {
		return osnovicaZaRegistraciju;
	}
	public static void setOsnovicaZaRegistraciju(float osnovicaZaRegistraciju) {
		Vozilo.osnovicaZaRegistraciju = osnovicaZaRegistraciju;
	}
	
	@Override
	public String toString() {
		return "Vozilo - marka: " + marka + ", model: " + model + ", kubikaza: " + kubikaza + ", godiste: " + godiste + "]";
	}
	
	public float iznosRegistracije() {
		return 0;
	}
}
