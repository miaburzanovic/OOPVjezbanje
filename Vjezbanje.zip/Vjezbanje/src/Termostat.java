
public class Termostat {
	private int minTemp=16;
	private int maxTemp=28;
	private String mod;
	
	public Termostat(int minTemp, int maxTemp, String mod) {
		this.minTemp = minTemp;
		this.maxTemp = maxTemp;
		this.mod = mod;
	}
	public int getMinTemp() {
		return minTemp;
	}
	public void setMinTemp(int minTemp) {
		if(minTemp==16)
		this.minTemp = minTemp;
	}
	public int getMaxTemp() {
		return maxTemp;
	}
	public void setMaxTemp(int maxTemp) {
		if(maxTemp==28)
		this.maxTemp = maxTemp;
	}
	public String getMod() {
		return mod;
	}
	public void setMod(String mod) {
		if(mod=="GRIJANJE" || mod=="HLADJENJE")
		this.mod = mod;
	}
	
	public int korakPromjene(int tren, int cilj) {
		if(this.mod.equals("GRIJANJE") && tren<cilj)
			return tren+1;
		else if(this.mod.equals("GRIJANJE"))
			return tren;
		else if(this.mod.equals("HLADJENJE") && tren>cilj)
			return tren-1;
		else
			return tren;
	}
	

}
