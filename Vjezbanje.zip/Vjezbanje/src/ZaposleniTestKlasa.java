
public class ZaposleniTestKlasa {
	public static void main(String[] args) {
	Zaposleni z1 = new Zaposleni("Marko","Markovic",700,15);
	Zaposleni z2 = new Zaposleni("Janko","Jankovic",900,7);
	Zaposleni z3 = new Zaposleni("Ivan","Ivanovic",500,5);
	z1.setPlata(650);
	z2.setGodine_staza(8);
	double plata = z3.getPlata();
	z3.povecaj();
	z1.povecaj();
	z1.ispisi();
	z2.ispisi();
	z3.ispisi();
	System.out.println("Nakon plata zaposlenog "+z3.getIme()+" je "+plata);
	}
}
