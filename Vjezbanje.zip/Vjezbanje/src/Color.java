
public class Color {
	private int red;
	private int green;
	private int blue;
	
	public Color(int red, int green, int blue) {
		this.red = red;
		this.green = green;
		this.blue = blue;
	}
	public int getRed() {
		return red;
	}
	public void setRed(int red) {
		if(red>=0 &&  red<=255)
		this.red = red;
		else {
			System.out.println("Boja red izlazi iz opsega");
		}
	}
	public int getGreen() {
		return green;
	}
	public void setGreen(int green) {
	if(green>=0 &&  green<=255)
		this.green = green;
	else {
		System.out.println("Boja green izlazi iz opsega");
	}
	}
	public int getBlue() {
		return blue;
	}
	public void setBlue(int blue) {
		if(blue>=0 &&  blue<=255)
		this.blue = blue;
		else {
			System.out.println("Boja blue izlazi iz opsega");
		}
	}
	
	public void addRed(int change) {
		int novaVrijednost = this.red+change;
		if(novaVrijednost<0) {
			System.out.println("Boja izlazi iz opsega. Postavlja se na vrijednost 0");
			this.setRed(0);
		}
		else if(novaVrijednost>255) {
			System.out.println("Boja izlazi iz opsega. Postavlja se na vrijednost 255");
			this.setRed(255);
		}
		else {
			this.setRed(novaVrijednost);
		}
	}
	
	public void addGreen(int change) {
		int novaVrijednost = this.green+change;
		if(novaVrijednost<0) {
			System.out.println("Boja izlazi iz opsega. Postavlja se na vrijednost 0");
			this.setGreen(0);
		}
		else if(novaVrijednost>255) {
			System.out.println("Boja izlazi iz opsega. Postavlja se na vrijednost 255");
			this.setGreen(255);
		}
		else {
			this.setGreen(novaVrijednost);
		}
	}
	
	public void addBlue(int change) {
		int novaVrijednost = this.blue+change;
		if(novaVrijednost<0) {
			System.out.println("Boja izlazi iz opsega. Postavlja se na vrijednost 0");
			this.setBlue(0);
		}
		else if(novaVrijednost>255) {
			System.out.println("Boja izlazi iz opsega. Postavlja se na vrijednost 255");
			this.setBlue(255);
		}
		else {
			this.setBlue(novaVrijednost);
		}
	}
	
	public void printColor() {
		System.out.println("red: "+this.red+" , green: "+this.green+" , blue: "+this.blue);
	}
}
