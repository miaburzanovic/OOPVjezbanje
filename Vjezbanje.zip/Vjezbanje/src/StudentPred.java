import java.util.ArrayList;

public class StudentPred {
	private String ime;
	private String prezime;
	private String brojIndeksa;
	private String adresa;
	private int brojBodova;
	private boolean polozioIliNe;
	private static float prolazNaIspitu;
	
	public StudentPred() {
		ime = "";
		prezime = "";
		brojIndeksa = "";
		adresa = "";
		brojBodova = 0;
		polozioIliNe = false;
	}
	
	public StudentPred(String ime, String prezime, String brojIndeksa, String adresa, int brojBodova,
			boolean polozioIliNe) {
		this.ime = ime;
		this.prezime = prezime;
		this.brojIndeksa = brojIndeksa;
		this.adresa = adresa;
		this.brojBodova = brojBodova;
		this.polozioIliNe = polozioIliNe;
	}
	
	

	public static float getProlazNaIspitu() {
		return prolazNaIspitu;
	}

	public static void setProlazNaIspitu(float prolazNaIspitu) {
		StudentPred.prolazNaIspitu = prolazNaIspitu;
	}

	public String getIme() {
		return ime;
	}

	public void setIme(String ime) {
		this.ime = ime;
	}

	public String getPrezime() {
		return prezime;
	}

	public void setPrezime(String prezime) {
		this.prezime = prezime;
	}

	public String getBrojIndeksa() {
		return brojIndeksa;
	}

	public void setBrojIndeksa(String brojIndeksa) {
		this.brojIndeksa = brojIndeksa;
	}

	public String getAdresa() {
		return adresa;
	}

	public void setAdresa(String adresa) {
		this.adresa = adresa;
	}

	public int getBrojBodova() {
		return brojBodova;
	}

	public void setBrojBodova(int brojBodova) {
		if(brojBodova>0)
		this.brojBodova = brojBodova;
	}

	public boolean isPolozioIliNe() {
		return polozioIliNe;
	}

	public void setPolozioIliNe(boolean polozioIliNe) {
		this.polozioIliNe = polozioIliNe;
	}
	
	
	public void polozio() {
		if(prolazNaIspitu<=brojBodova) {
			this.polozioIliNe = true;
		}
		else {
			this.polozioIliNe = false;
		}
	}
	
	public static ArrayList<StudentPred> komsije (ArrayList<StudentPred> lista, String nazivUlice) {
		ArrayList<StudentPred> novaLista = new ArrayList<>();
		for(StudentPred a : lista) {
			if(a.getAdresa().equalsIgnoreCase(nazivUlice)) {
				novaLista.add(a);
			}
		}
		return novaLista;
	}
	
	public static ArrayList<StudentPred> poloziliIspit (ArrayList<StudentPred> lista, int granica){
		ArrayList<StudentPred> listaPolozenih = new ArrayList<>();
		for(StudentPred a : lista) {
			if(a.getBrojBodova()>=granica) {
				if(a.isPolozioIliNe()==false) {
					a.setPolozioIliNe(true);
				}
				listaPolozenih.add(a);
			}
		}
		return listaPolozenih;
	}

}
