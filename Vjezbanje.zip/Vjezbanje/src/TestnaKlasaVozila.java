
public class TestnaKlasaVozila {
	public static void main(String[] args) {
		Vozilo.setOsnovicaZaRegistraciju(5);
	AutomobilV a = new AutomobilV("Porsche","Macan",3000,2019,4,4);
	Motocikl m = new Motocikl("Marka","Model",1000,2020,500);
	Kamion k = new Kamion("Marka kamiona", "Model kamiona", 4000, 2025, 5);
	
	float ukupno = a.iznosRegistracije() + m.iznosRegistracije() + k.iznosRegistracije();
	
	System.out.println("Ukupan iznos registracije svih vozila voznog parka je: "+ukupno);
	}
}
