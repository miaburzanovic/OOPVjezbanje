
public class Televizor {
	private int brojKanala;
	private String nazivKanala;
	private int jacinaTona;
	
	
	public Televizor(int brojKanala, String nazivKanala, int jacinaTona) {
		setBrojKanala(brojKanala);
		setNazivKanala(nazivKanala);
		setJacinaTona(jacinaTona);
	}
	public int getBrojKanala() {
		return brojKanala;
	}
	public void setBrojKanala(int brojKanala) {
		if(brojKanala>=1)
		this.brojKanala = brojKanala;
	}
	public String getNazivKanala() {
		return nazivKanala;
	}
	public void setNazivKanala(String nazivKanala) {
		if(nazivKanala!=null)
		this.nazivKanala = nazivKanala;
	}
	public int getJacinaTona() {
		return jacinaTona;
	}
	public void setJacinaTona(int jacinaTona) {
		if(jacinaTona>=0 && jacinaTona<=10)
		this.jacinaTona = jacinaTona;
	}
	
	public void pojacajTon() {
		if(jacinaTona<10) {
		this.setJacinaTona(getJacinaTona()+1);
		}
		else {
			System.out.println("Jacina tona je vec na max");
		}
	}
	
	public void ispisi() {
		System.out.println("Broj kanala je"+this.brojKanala+" , naziv kanala je "+this.nazivKanala+" a jacina tona je"+this.jacinaTona);
	}
	
}
