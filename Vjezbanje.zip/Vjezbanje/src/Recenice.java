import java.util.ArrayList;

public class Recenice {
	
	public static String vratiRecenice(String a, String b) {
		if(a==null || b==null) {
			return "";
		}
		a.trim();
		b.trim();
		String[] rijeciA = a.split(" ");
		String[] rijeciB = b.split(" ");
		ArrayList<String> nova = new ArrayList<>();
		for(String aa : rijeciA) {
			boolean pronadjena = false;
			for (String bb : rijeciB) {
				if(aa.equalsIgnoreCase(bb)) {
					pronadjena = true;
					break;
				}
				}
				if(pronadjena==true) {
					nova.add(aa);
				}
				else {
					nova.add("[-"+aa+"-]");
		}
		}
		for(String bb: rijeciB) {
			boolean postoji = false;
			for(String aa : rijeciA) {
				if(bb.equalsIgnoreCase(aa)) {
					postoji = true;
					break;
				}
				if(postoji==false) {
					nova.add("{+"+bb+"+}");
				}
			}
		}
		
		return String.join(" ",nova);
	}
}
