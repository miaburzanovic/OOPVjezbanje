
public class ZapisStringa {

	public static double prosjecnaTemperatura(String log) {
		
		if(log == null || log.isEmpty()) {
			return 0.0;
		}
		
		String[] zapisi = log.split("\\|");
		double suma = 0.0;
		int brojac=0;
		
		for(String a:zapisi) {
			if(!a.contains("T=") || !a.contains("TS=") || a.contains("H=") || a.contains("T")) {
				continue; // Preskoci neregularan zapis
			}
			
			int pozicijaT = a.indexOf("T=")+2;
			int pozicijaC = a.indexOf("C");
			String temp = a.substring(pozicijaT,pozicijaC);
			double temperatura = Double.parseDouble(temp);
			
			String minut = a.substring(a.length()-2);
			int min = Integer.parseInt(minut);
			
			if(min>=10 && min<=20) {
				suma+=temperatura;
				brojac++;
			}
			
			if(brojac==0) {
				return 0.0;
			}
		}
		double prosjek = suma/brojac;
		return (Math.round(prosjek*10.0)/10.0);
		
	}

}
