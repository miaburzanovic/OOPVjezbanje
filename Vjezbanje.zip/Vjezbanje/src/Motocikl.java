
public class Motocikl extends Vozilo {
	private int kilometraza;

	public Motocikl() {
		this.setMarka(null);
		this.setModel(null);
		this.setKubikaza(0);
		this.setGodiste(1945);
		kilometraza = 0;
	}
	
	public Motocikl(String marka, String model, int kubikaza, int godiste, int kilometraza) {
		super(marka, model, kubikaza, godiste);
		this.kilometraza = kilometraza;
	}

	public int getKilometraza() {
		return kilometraza;
	}

	public void setKilometraza(int kilometraza) {
		if(kilometraza>=0)
		this.kilometraza = kilometraza;
	}

	@Override
	public String toString() {
		return "Motocikl - kilometraza: " + kilometraza + ", marka: " + getMarka() + ", model:" + getModel()
				+ ", kubikaza: " + getKubikaza() + ", godiste: " + getGodiste();
	}
	
	@Override
	
	public float iznosRegistracije() {
		float iznosM = (this.getKubikaza()/5 - getKilometraza()/1000)*Vozilo.getOsnovicaZaRegistraciju();
		return iznosM;
	}

}
