import java.util.ArrayList;

public class Film {
	private String naziv;
	private String zanr;
	private int ocjena;
	private int trajanjeMin;
	
	public Film() {
		this.naziv = "Nepoznat";
		this.zanr = "Nepoznat";
		this.ocjena = 0;
		this.trajanjeMin = 0;
	}
	
	
	public Film(String naziv, String zanr, int ocjena, int trajanjeMin) {
		this.naziv = naziv;
		this.zanr = zanr;
		this.ocjena = ocjena;
		this.trajanjeMin = trajanjeMin;
	}
	public String getNaziv() {
		return naziv;
	}
	public void setNaziv(String naziv) {
		if(naziv!=null)
		this.naziv = naziv;
	}
	public String getZanr() {
		return zanr;
	}
	public void setZanr(String zanr) {
		if(zanr!=null)
		this.zanr = zanr;
	}
	public int getOcjena() {
		return ocjena;
	}
	public void setOcjena(int ocjena) {
		if(ocjena>0)
		this.ocjena = ocjena;
	}
	public int getTrajanjeMin() {
		return trajanjeMin;
	}
	public void setTrajanjeMin(int trajanjeMin) {
		if(trajanjeMin>0)
		this.trajanjeMin = trajanjeMin;
	}
	
	public static Film najduziFilm(ArrayList<Film> lista) {
		if(lista==null || lista.isEmpty()) {
			Film f = new Film(null,null,0,0);
			return f;
		}
		int max = 0;
		Film maxFilm  = lista.get(0);
		for(Film a : lista) {
			if(a.getTrajanjeMin()>max) {
				max=a.getTrajanjeMin();
				maxFilm=a;
			}
		}
		
		return maxFilm;
	}
	
	public static ArrayList<Film> filmoviPoZanru(ArrayList<Film> lista, String zanr){
		ArrayList<Film> istiZanr = new ArrayList<>();
		if(lista == null || lista.isEmpty() || zanr == null) {
			return istiZanr;  // Prazna ArrayList-a
		}
		
		for(Film a : lista) {
			if(a.getZanr().equalsIgnoreCase(zanr)) {
				istiZanr.add(a);
			}
		}
		
		return istiZanr;
	}
	
	public static double prosjecnaOcjena(ArrayList<Film> lista) {
		if(lista == null || lista.isEmpty()) {
			return 0.0;
		}
		
		double suma=0.0;
		
		for(Film a : lista) {
			suma+=a.getOcjena();		
			}
		
		return suma/lista.size();
		}

}
