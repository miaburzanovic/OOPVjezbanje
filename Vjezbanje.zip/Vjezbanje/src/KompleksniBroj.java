
public class KompleksniBroj {
	private int realniDio;
	private int kompleksniDio;
	
	public KompleksniBroj() {
		this.realniDio=0;
		this.kompleksniDio=0;
	}
	public KompleksniBroj(int realniDio, int kompleksniDio) {
		this.realniDio = realniDio;
		this.kompleksniDio = kompleksniDio;
	}
	public int getRealniDio() {
		return realniDio;
	}
	public void setRealniDio(int realniDio) {
		this.realniDio = realniDio;
	}
	public int getKompleksniDio() {
		return kompleksniDio;
	}
	public void setKompleksniDio(int kompleksniDio) {
		this.kompleksniDio = kompleksniDio;
	}
	
	public String dajBroj() {
		return "KompleksniBroj " + realniDio + "" + kompleksniDio + "j";
	}
	
	public static KompleksniBroj saberi(KompleksniBroj k1, KompleksniBroj k2) {
		KompleksniBroj k = new KompleksniBroj();
		k.setRealniDio(k1.getRealniDio()+k2.getRealniDio());
		k.setKompleksniDio(k1.getKompleksniDio()+k2.getKompleksniDio());
		return k;
	}
	
	public static KompleksniBroj oduzmi(KompleksniBroj k1, KompleksniBroj k2) {
		KompleksniBroj k = new KompleksniBroj();
		k.setRealniDio(k1.getRealniDio()-k2.getRealniDio());
		k.setKompleksniDio(k1.getKompleksniDio()-k2.getKompleksniDio());
		return k;
	}
	
	public static KompleksniBroj pomnozi(KompleksniBroj k1, KompleksniBroj k2) {
		KompleksniBroj k = new KompleksniBroj();
		k.setRealniDio(k1.getRealniDio()*k2.getRealniDio()-k1.getKompleksniDio()*k2.getKompleksniDio());
		k.setKompleksniDio(k1.getRealniDio()*k2.getKompleksniDio()+k1.getKompleksniDio()*k2.getRealniDio());
		return k;
	}
	
	

}
