
public class App {

	public static void main(String[] args) {
		BankovniRacun b = new BankovniRacun("Petar Petrovic",2000);
		Transakcija t1 = new Transakcija(250,"uplata","povrat pdv-a");
		Transakcija t2 = new Transakcija(100,"isplata","rata za kredit");
		if(t1.jeUplata()==true) {
		b.uplati(t1.getIznos());
		}
		else {
			b.isplati(t1.getIznos());
		}
		if(t2.jeUplata()==true) {
			b.uplati(t2.getIznos());
		}
		else {
			b.isplati(t2.getIznos());
		}
		b.ispisi();

	}

}
