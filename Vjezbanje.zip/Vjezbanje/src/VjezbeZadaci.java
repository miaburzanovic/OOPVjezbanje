import java.util.Scanner;

public class VjezbeZadaci {
	
	// Vjezbe 2
	// Prvi zadatak
	/*
	public static void main(String[] args) {
		Scanner unos = new Scanner(System.in);
		System.out.println("Unesite trocifreni broj");
		int n = unos.nextInt();
		int proizvod = 1;
		int zbir = 0;
		int temp = 0;
		
		while(n>0) {
			temp=n%10;
			proizvod*=temp;
			zbir+=temp;
			n=n/10;
		}
		
		int kod = proizvod-zbir;
		System.out.println("Kod je "+kod);
	}
	*/
	
	// Drugi zadatak
	/*
	public static void main(String[] args) {
		Scanner unos = new Scanner(System.in);
		System.out.println("Unesite cijeli broj");
		int n = unos.nextInt();
		if(n>=0) {
			System.out.println("Broj je pozitivan");
		}
		else {
			System.out.println("Broj je negativan");
		}
		if(n%2==0) {
			System.out.println("Broj je paran");
		}
		else {
			System.out.println("Broj je neparan");
		}
	}
	*/
	
	// Treci zadatak
	/*
	public static void main(String[] args) {
		Scanner unos = new Scanner(System.in);
		System.out.println("Unesite cijeli broj");
		int n = unos.nextInt();
		if(n<1 || n>12) {
			System.out.println("Nedozvoljen broj");
		}
		else {
			System.out.println(+n+"-ti mjesec");
		}
	}
	*/
	
	// Sesti zadatak
	/*
	public static void main (String[] args) {
		Scanner unos = new Scanner(System.in);
		System.out.println("Unesite cijeli broj");
		int n = unos.nextInt();
		if(n%5==0 && n%3!=0) {
			System.out.println("Fizz");
		}
		else if(n%3==0 && n%5!=0) {
			System.out.println("Buzz");
		}
		else if(n%5==0 && n%3==0) {
			System.out.println("Fizzbuzz");
		}
		else if(n%3!=0 && n%5!=0) {
			System.out.println(n);
		}
	}
	*/
	
	// Sedmi zadatak
	/*
	public static void main(String[] args) {
		Scanner unos = new Scanner(System.in);
		System.out.println("Unesite duzinu niza");
		int n = unos.nextInt();
		int[] domacinstva = new int[n];
		int ukupno=0;
		int veciPotrosaci=0;
		System.out.println("Unesite potrosnju domacinstava");
		for(int i=0; i<n; i++) {
			domacinstva[i]=unos.nextInt();
			ukupno+=domacinstva[i];
			if(domacinstva[i]>500) {
				veciPotrosaci+=domacinstva[i];
			}
		}
		System.out.println("Ukupna potrosnja je "+ukupno+" a suma domacinstava cija je potrosnja veca od 500kmW je "+veciPotrosaci);
	}
	*/
	
	// Osmi zadatak, Narcistic number
	/*
	public static void main(String[] args) {
		Scanner unos = new Scanner(System.in);
		System.out.println("Unesite cijeli broj");
		int n = unos.nextInt();
		int brojac = 0;
		int suma=0;
		int temp=n;
		while(n>0) {
			temp=temp/10;
			brojac++;
		}
		int cifra=0;
		while(n>0) {
			cifra=temp%10;
			suma+=(int)Math.pow(cifra,brojac);
			temp=temp/10;
		}
		if(suma==n) {
			System.out.println("Broj je Narcisstic");
		}
		else {
			System.out.println("Broj nije Narcisstic");
		}
	}
	*/
	
	// Deveti zadatak

	public static void main(String[] args) {
		Scanner unos = new Scanner(System.in);
		System.out.println("Unesite duzinu niza");
		int n = unos.nextInt();
		int[] parking = new int[n];
		int zarada = 0;
		System.out.println("Unesite br sati provedenih na parkingu po automobilu");
		for(int i=0;i<n;i++) {
			parking[i]=unos.nextInt();
			if(parking[i]<=5) {
				zarada+=parking[i]*2;
			}
			else {
				zarada+=5*2+(parking[i]-5)*1;
			}
		}
	System.out.println("Ukupna zarada parking servisa je "+zarada);
}	
}
