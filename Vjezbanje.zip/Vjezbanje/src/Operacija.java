
public class Operacija {
	
	public static int aritmetickiIzraz(String a) {
		a=a.trim();
		if(a== null || a.isEmpty()) {
			return 0;
		}
		if(a.contains("\\+")) {
			String[] izraz1 = a.split("+");
			String izraz11 = izraz1[0];
			int iz11 = Integer.parseInt(izraz11);
			String izraz22 = izraz1[1];
			int iz22 = Integer.parseInt(izraz22);
			return iz11+iz22;
		}
		else if(a.contains("-")) {
			String[] izraz2 = a.split("-");
			String izraz21 = izraz2[0];
			int iz211 = Integer.parseInt(izraz21);
			String izraz222 = izraz2[1];
			int iz222 = Integer.parseInt(izraz222);
			return iz211-iz222;
		}
		else if(a.contains("\\*")) {
			String[] izraz3 = a.split("*");
			String izraz31 = izraz3[0];
			int iz311 = Integer.parseInt(izraz31);
			String izraz32 = izraz3[1];
			int iz322 = Integer.parseInt(izraz32);
			return iz311*iz322;
		}
		else if(a.contains("/")) {
			String[] izraz4 = a.split("/");
			String izraz41 = izraz4[0];
			int iz41 = Integer.parseInt(izraz41);
			String izraz42 = izraz4[1];
			int iz42 = Integer.parseInt(izraz42);
			return (int)(iz41/iz42);
		}
		else {
			return 0;
		}
	}

}
