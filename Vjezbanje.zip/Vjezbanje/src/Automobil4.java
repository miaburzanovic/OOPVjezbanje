// Cetvrta grupa zadataka
import java.util.ArrayList;


public class Automobil4 {
	private String markaAuta;
	private int godisteAuta;
	private int snagaMotora;
	private boolean prodato;
	private int kubikazaMotora;
	private boolean registrovan;
	
	public static int brojProdatih=0;
	
	public Automobil4(String markaAuta, int godisteAuta, int snagaMotora, boolean prodato, int kubikazaMotora,
			boolean registrovan) {
		this.markaAuta = markaAuta;
		this.godisteAuta = godisteAuta;
		this.snagaMotora = snagaMotora;
		this.prodato = prodato;
		this.kubikazaMotora = kubikazaMotora;
		this.registrovan = registrovan;
	}
	public String getMarkaAuta() {
		return markaAuta;
	}
	public void setMarkaAuta(String markaAuta) {
		if(markaAuta!=null)
		this.markaAuta = markaAuta;
	}
	public int getGodisteAuta() {
		return godisteAuta;
	}
	public void setGodisteAuta(int godisteAuta) {
		this.godisteAuta = godisteAuta;
	}
	public int getSnagaMotora() {
		return snagaMotora;
	}
	public void setSnagaMotora(int snagaMotora) {
		if(snagaMotora>0)
		this.snagaMotora = snagaMotora;
	}
	public boolean isProdato() {
		return prodato;
	}
	public void setProdato(boolean prodato) {
		this.prodato = prodato;
	}
	public int getKubikazaMotora() {
		return kubikazaMotora;
	}
	public void setKubikazaMotora(int kubikazaMotora) {
		if(kubikazaMotora>0)
		this.kubikazaMotora = kubikazaMotora;
	}
	public boolean isRegistrovan() {
		return registrovan;
	}
	public void setRegistrovan(boolean registrovan) {
		if(this.godisteAuta>1985)
		this.registrovan = true;
		else
			this.registrovan=false;
	}
	
	@Override
	public String toString() {
		return "Podaci automobila - marka: " + markaAuta + ", godiste: " + godisteAuta + ", snaga motora: " + snagaMotora
				+ ", prodato: " + prodato + ", kubikaza motora : " + kubikazaMotora + ", registrovano: " + registrovan + "]";
	}
	
	public static ArrayList<Automobil4> mogucnostRegistracije(ArrayList<Automobil4> sviAutomobili){
		ArrayList<Automobil4> neregistrovani = new ArrayList<>();
		for(Automobil4 a : sviAutomobili)
		if(a.getGodisteAuta()>=1985 && a.isRegistrovan()==false) {
			neregistrovani.add(a);
		}
		return neregistrovani;
	}
	
	public double iznosRegistracije() {
		if(this.godisteAuta>=1985 && this.godisteAuta<=2000) {
			return 3.0*this.kubikazaMotora*this.snagaMotora;
		}
		else if(this.godisteAuta>=2001 && this.godisteAuta<=2010) {
			return 2.0*this.kubikazaMotora*this.snagaMotora;
		}
		else if(this.godisteAuta>=2011) {
			return 1.5*this.kubikazaMotora*this.snagaMotora;
		}
		else {
			System.out.println("Auto se ne moze registrovati");
			return 0;
	}
	}
	
	public static double iznosRegistracijeSvih(ArrayList<Automobil4> sviAutomobili) {
	    double suma = 0;
	    for (Automobil4 a : sviAutomobili) {
	        if (a.getGodisteAuta() >= 1985) {
	            suma += a.iznosRegistracije();
	        }
	    }
	    return suma;
	}
}
