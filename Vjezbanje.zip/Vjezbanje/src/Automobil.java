
public class Automobil {
	private String marka;
	private String model;
	private int godiste;
	private int brzina;
	
	public Automobil(String marka, String model, int godiste, int brzina) {
		this.marka = marka;
		this.model = model;
		this.godiste = godiste;
		this.brzina = brzina;
	}
	public String getMarka() {
		return marka;
	}
	public void setMarka(String marka) {
		this.marka = marka;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public int getGodiste() {
		return godiste;
	}
	public void setGodiste(int godiste) {
		if(godiste>1945)
		this.godiste = godiste;
	}
	public int getBrzina() {
		return brzina;
	}
	public void setBrzina(int brzina) {
		if(brzina>0)
		this.brzina = brzina;
	}
	
	public void ubrzaj(int vrijednost) {
		this.brzina=brzina+vrijednost;
		if(brzina>200) {
			System.out.println("Brzina ne smije preci 200");
			this.brzina=200;
		}
	}
	public void uspori(int vrijednost) {
		this.brzina=brzina-vrijednost;
		if(brzina<0) {
			System.out.println("Brzina ne smije pasti ispod 0");
			this.brzina=0;
		}
	}
	
	public void ispisi() {
		System.out.println("Marka automobila je " +this.marka+" , model "+this.model+" , godiste "+this.godiste+" a brzina je "+this.brzina);
	}
	
}
