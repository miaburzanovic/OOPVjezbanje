import java.util.ArrayList;


public class Destinacija {
	private String naziv;
	private String drzava;
	private int ocjena;
	private double udaljenostKm;
	private int brojPosjeta;
	
	public Destinacija(String naziv, String drzava, int ocjena, double udaljenostKm, int brojPosjeta) {
		this.naziv = naziv;
		this.drzava = drzava;
		this.ocjena = ocjena;
		this.udaljenostKm = udaljenostKm;
		this.brojPosjeta = brojPosjeta;
	}
	public String getNaziv() {
		return naziv;
	}
	public void setNaziv(String naziv) {
		if(naziv!=null)
		this.naziv = naziv;
	}
	public String getDrzava() {
		return drzava;
	}
	public void setDrzava(String drzava) {
		if(drzava!=null)
		this.drzava = drzava;
	}
	public int getOcjena() {
		return ocjena;
	}
	public void setOcjena(int ocjena) {
		if(ocjena>=0 && ocjena<=10)
		this.ocjena = ocjena;
	}
	public double getUdaljenostKm() {
		return udaljenostKm;
	}
	public void setUdaljenostKm(double udaljenostKm) {
		if(udaljenostKm>0)
		this.udaljenostKm = udaljenostKm;
	}
	public int getBrojPosjeta() {
		return brojPosjeta;
	}
	public void setBrojPosjeta(int brojPosjeta) {
		if(brojPosjeta>0)
		this.brojPosjeta = brojPosjeta;
	}
	
	public static ArrayList<Destinacija> ocjenaBlizina(ArrayList<Destinacija> Destinacije){
		ArrayList<Destinacija> rezultat = new ArrayList<>();
		for(Destinacija a:Destinacije) {
			if(a.getOcjena()>8 && a.getUdaljenostKm()<1000) {
				rezultat.add(a);
			}
		}
		return rezultat;
	}
	
	public static Destinacija najposjecenija(ArrayList<Destinacija> d) {
		int max = 0;
		Destinacija maxPosjecena= d.get(0);
		for(Destinacija dd : d) {
			if(dd.getBrojPosjeta()>max) {
				max=dd.getBrojPosjeta();
				maxPosjecena=dd;
			}
		}
		
		return maxPosjecena;
	}
	
	public static void najmanjaPosjecenost(ArrayList<Destinacija> d) {
		if(d == null || d.isEmpty()) {
			System.out.println("Lista je prazna");
		}
		
		for(int i=0;i<d.size()-1;i++) {
			for(int j=0;j<d.size()-i-1;j++) {
				
				Destinacija d1 = d.get(j);
				Destinacija d2= d.get(j+1);
				
				if(d1.getBrojPosjeta()>d2.getBrojPosjeta()) {
					d.set(j, d2);
					d.set(j+1, d1);
				}
			}
		}
	}


}
