
public class Validacija {
	
	public static String validacijaStringa (String log) {
		if (log ==  null || log.isEmpty()) {
			return "Greska. Unos je prazan";
		}
		
		String sadrzaj = log.substring(1,log.length()-1);
		
		String[] pojedinacno = sadrzaj.split(":");
		
		boolean host = false;
		boolean port = false;
		boolean secure = false;
		boolean paths = false;
		
		for (String a:pojedinacno) {
			
			String[] dio = a.split("=");
			
			if(dio.length!=2) {
				return "Neispravan format";
			}
			
			String kljuc = dio[0].trim();
			String vrijednost = dio[1].trim();
			
			if(kljuc.equals("host")) {
				host=true;
				if(vrijednost.isEmpty()) {
					return "Vrijednost host-a je prazna";
				}
			}
			
			else if(kljuc.equals("port")) {
				port = true;
				if(vrijednost.isEmpty()) {
					return "Vrijednost port-a je prazna";
				}
				int vr = Integer.parseInt(vrijednost);
				if(vr<0) {
					return "Vrijednost port-a mora biti cijeli broj";
				}
			}
			
			else if(kljuc.equals("secure")) {
				secure = true;
				if(vrijednost!="true" || vrijednost!="false") {
					return "Vrijednost secure mora biti ili true ili false";
				}
			}
			
			else if(kljuc.equals("paths")) {
				paths = true;
				
				String[] p = vrijednost.split(",");
				
				if(p == null) {
					return "Paths ne moze biti prazan";
				}
				for(String x : p)
				 if(x.trim().isEmpty()) {
					return "Neka od putanja fali";
				}
			}
		}
		
		if(host == true && port== true && secure == true && paths==true) {
			return "OK";
		}
		else {
			return "Jedan od kljuceva fali";
		}
	}

}
