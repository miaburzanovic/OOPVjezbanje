import java.util.ArrayList;

public class Auto {
	private String markaAuta;
	private int godisteAuta;
	private int snagaMotora;
	private boolean prodato;
	private int kubikazaMotora;
	private boolean registrovan;
	private static int prodati;
	
	public Auto(String markaAuta, int godisteAuta, int snagaMotora, boolean prodato, int kubikazaMotora,
			boolean registrovan) {
		this.markaAuta = markaAuta;
		this.godisteAuta = godisteAuta;
		this.snagaMotora = snagaMotora;
		this.prodato = prodato;
		this.kubikazaMotora = kubikazaMotora;
		if(godisteAuta<1985) {
			this.registrovan = false;
		}
	}

	public String getMarkaAuta() {
		return markaAuta;
	}

	public void setMarkaAuta(String markaAuta) {
		this.markaAuta = markaAuta;
	}

	public int getGodisteAuta() {
		return godisteAuta;
	}

	public void setGodisteAuta(int godisteAuta) {
		this.godisteAuta = godisteAuta;
	}

	public int getSnagaMotora() {
		return snagaMotora;
	}

	public void setSnagaMotora(int snagaMotora) {
		this.snagaMotora = snagaMotora;
	}

	public boolean isProdato() {
		return prodato;
	}

	public void setProdato(boolean prodato) {
		this.prodato = prodato;
	}

	public int getKubikazaMotora() {
		return kubikazaMotora;
	}

	public void setKubikazaMotora(int kubikazaMotora) {
		this.kubikazaMotora = kubikazaMotora;
	}

	public boolean isRegistrovan() {
		return registrovan;
	}

	public void setRegistrovan(boolean registrovan) {
		this.registrovan = registrovan;
	}
	
	public static int getProdati() {
		return prodati;
	}

	public static void setProdati(int prodati) {
		Auto.prodati = prodati;
	}


	public void ispisi() {
		System.out.println("Auto - marke: " + markaAuta + ", godiste: " + godisteAuta + ", snage motora: " + snagaMotora
				+ ", status prodaje: " + prodato + ", kubikaza motora: " + kubikazaMotora + ", registracija: " + registrovan);
	}
	
	public static ArrayList<Auto> mogucnostRegistracije(ArrayList<Auto> lista){
		if(lista == null || lista.isEmpty()) {
			return null;
		}
		ArrayList<Auto> moguci = new ArrayList<>();
		for(Auto a:lista) {
			if(a.getGodisteAuta()>1985 && a.isRegistrovan()==false) {
				moguci.add(a);
			}
		}
		return moguci;
	}
	
	public static double iznosRegistracije(ArrayList<Auto> lista) {
		if(lista ==  null || lista.isEmpty()) {
			return 0.0;
		}
		
		double suma = 0.0;
		
		for(Auto a : lista) {
			if(a.getGodisteAuta()>1985 && a.getGodisteAuta()<=2000) {
				suma+=3.0*a.getKubikazaMotora()*a.getSnagaMotora();
			}
			else if(a.getGodisteAuta()>2000 && a.getGodisteAuta()<=2010) {
				suma+=2.0*a.getKubikazaMotora()*a.getSnagaMotora();
			}
			else if(a.getGodisteAuta()>=2011) {
				suma+=1.5*a.getKubikazaMotora()*a.getSnagaMotora();
			}
		}
		return suma;
	}

}
