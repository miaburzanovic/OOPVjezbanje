import java.util.Scanner;
import java.util.Random;

public class AnalizaNizaTest {
	
	public static void main(String[] args) {
		Scanner unos = new Scanner(System.in);
		Random rand = new Random();
		System.out.println("Unesite duzinu niza");
		int n = unos.nextInt();
		int[] niz = new int[n];
		for(int i=0;i<n;i++) {
			niz[i]=rand.nextInt();
		}
		double parniPoz = AnalizaNiza.nadjiParniProsjek(niz);
		System.out.println("Prosjecna vrijednist parnih brojeva unijetog niza je "+parniPoz);
		
		for(int i=0;i<n;i++) {
			if(niz[i]%2==0) {
				niz[i]=niz[i]*(-1);
			}
			else {
				niz[i]=1/niz[i];
			}
		}
	}

}
