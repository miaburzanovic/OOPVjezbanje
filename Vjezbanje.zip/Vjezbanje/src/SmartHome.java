
public class SmartHome {
	public static void main(String[] args) {
	Soba soba = new Soba(17,20);
	Termostat t = new Termostat(16,28,"GRIJANJE");
	while (soba.getTrenTemp() < soba.getCiljTemp()) {
        int novaTemp = t.korakPromjene(soba.getTrenTemp(), soba.getCiljTemp());
        soba.setTrenTemp(novaTemp);
        System.out.println("Trenutna temperatura je: " + soba.getTrenTemp());
	}
}
}