
public class GeometryApp {

	public static void main(String[] args) {
		Pravougaonik pravougaonik = new Pravougaonik(2,3,5,4);
		Tacka tacka = new Tacka(3,3);
		boolean provjera;
		provjera = pravougaonik.sadrzi(tacka.getX(), tacka.getY());
		if(provjera==true) {
			System.out.println("Tacka pripada pravougaoniku");
		}
		else {
			System.out.println("Tacka ne pripada pravougaoniku");
		}

	}

}
