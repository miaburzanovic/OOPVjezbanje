
public class Zaposleni {
	private String ime;
	private String prezime;
	private int godine_staza;
	private double plata;
	
	
	public Zaposleni(String ime, String prezime, int godine_staza, double plata) {
		setIme(ime);
		setPrezime(prezime);
		setGodine_staza(godine_staza);
		setPlata(plata);
	}
	public String getIme() {
		return ime;
	}
	public void setIme(String ime) {
		this.ime = ime;
	}
	public String getPrezime() {
		return prezime;
	}
	public void setPrezime(String prezime) {
		this.prezime = prezime;
	}
	public int getGodine_staza() {
		return godine_staza;
	}
	public void setGodine_staza(int godine_staza) {
		if(godine_staza>0)
		this.godine_staza = godine_staza;
	}
	public double getPlata() {
		return plata;
	}
	public void setPlata(double plata) {
		if(plata>0.0)
		this.plata = plata;
	}
	
	public void ispisi() {
		System.out.println("Ime zaposlenog: "+this.getIme()+" prezime zaposlenog: "+this.getPrezime()+" godine staza: "+this.getGodine_staza());
	}
	
	public void povecaj() {
		if(this.getPlata()<800 && this.godine_staza>10) {
			this.setPlata(getPlata()*1.06);
		}
	}
}
