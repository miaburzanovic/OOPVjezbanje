
public class StudentskaSluzba {
	private String ime;
	private String prezime;
	private String brojIndeksa;
	private int ocjena1;
	private int ocjena2;
	private int ocjena3;
	
	public StudentskaSluzba(String ime, String prezime, String brojIndeksa, int ocjena1, int ocjena2, int ocjena3) {
		this.ime = ime;
		this.prezime = prezime;
		this.brojIndeksa = brojIndeksa;
		this.ocjena1 = ocjena1;
		this.ocjena2 = ocjena2;
		this.ocjena3 = ocjena3;
	}
	public String getIme() {
		return ime;
	}
	public void setIme(String ime) {
		if(ime != null)
		this.ime = ime;
	}
	public String getPrezime() {
		return prezime;
	}
	public void setPrezime(String prezime) {
		if(prezime!=null)
		this.prezime = prezime;
	}
	public String getBrojIndeksa() {
		return brojIndeksa;
	}
	public void setBrojIndeksa(String brojIndeksa) {
		this.brojIndeksa = brojIndeksa;
	}
	public int getOcjena1() {
		return ocjena1;
	}
	public void setOcjena1(int ocjena1) {
		if(ocjena1>0) // Ocjena ne moze biti negativna
		this.ocjena1 = ocjena1;
	}
	public int getOcjena2() {
		return ocjena2;
	}
	public void setOcjena2(int ocjena2) {
		if(ocjena2>0)
		this.ocjena2 = ocjena2;
	}
	public int getOcjena3() {
		return ocjena3;
	}
	public void setOcjena3(int ocjena3) {
		if(ocjena3>0)
		this.ocjena3 = ocjena3;
	}
	
	public double prosjecnaOcjena() {
		double prosjek = (this.getOcjena1() + this.getOcjena2() + this.getOcjena3())/3.0;
		return prosjek;
	}
	
	public boolean stipendija() {
		if (prosjecnaOcjena()>9.0) {
			return true;
		}
		else {
			return false;
		}
	}
	
	public void ispis() {
		if (stipendija()==true) {
			System.out.println("Ime: "+this.ime+" , Prezime: "+this.prezime+", Stipendija: Da");
		}
		else {
			System.out.println("Ime: "+this.ime+" , Prezime: "+this.prezime+", Stipendija: Ne");
		}
	}
	
	

}
