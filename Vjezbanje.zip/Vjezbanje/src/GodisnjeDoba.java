
public class GodisnjeDoba {
	
	public enum Sezona {
		PROLJECE(5,20),
		LJETO(20,35),
		JESEN(10,18),
		ZIMA(-5,5);
		
		private final int minTemp;
		private final int maxTemp;
		
		
		private Sezona(int minTemp, int maxTemp) {
			this.minTemp = minTemp;
			this.maxTemp = maxTemp;
		}


		public int getMinTemp() {
			return minTemp;
		}


		public int getMaxTemp() {
			return maxTemp;
		}
		
		
		public int raspon() {
			return maxTemp-minTemp;
		}
			
		public String opis() {
			return "U sezoni"+ this.name() +"prosjecne temperature se krecu od "+ this.minTemp +"C do "+ this.maxTemp+ " C.";
		}
		
	}



public static void main(String[] args) {
	System.out.println("Opisi svih sezona: ");
	for(Sezona s: Sezona.values()) {
		System.out.println(s.opis());
	}
	
	Sezona sezonaSaNajvecimRasponom = Sezona.values()[0];
	
	for(Sezona s: Sezona.values()) {
		if(s.raspon()>sezonaSaNajvecimRasponom.raspon()) {
			sezonaSaNajvecimRasponom = s;
		}
	}
	
	System.out.println("Sezona sa najvecim rasponom je "+sezonaSaNajvecimRasponom.name());
}
}