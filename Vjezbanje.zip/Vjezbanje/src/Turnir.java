import java.util.ArrayList;
import java.util.Random;

public class Turnir {
	private String nazivTurnira;
	private ArrayList<String[]> listaIgraca;
	private int brojRundi;
	
	
	public Turnir(String nazivTurnira, ArrayList<String[]> listaIgraca, int brojRundi) {
		this.nazivTurnira = nazivTurnira;
		this.listaIgraca = listaIgraca=null;
		this.brojRundi = brojRundi;
	}
	public String getNazivTurnira() {
		return nazivTurnira;
	}
	public void setNazivTurnira(String nazivTurnira) {
		this.nazivTurnira = nazivTurnira;
	}
	public ArrayList<String[]> getListaIgraca() {
		return listaIgraca;
	}
	public void setListaIgraca(ArrayList<String[]> listaIgraca) {
		this.listaIgraca = listaIgraca;
	}
	public int getBrojRundi() {
		return brojRundi;
	}
	public void setBrojRundi(int brojRundi) {
		if(brojRundi>0 && brojRundi<10)
		this.brojRundi = brojRundi;
	}
	
	public static ArrayList<String[]> dodajIgraca(ArrayList<String[]> lista, String imeIgraca){
		String[] igrac = { imeIgraca, "0"};
		lista.add(igrac);
		return lista;
	}
	
	public static ArrayList<String[]> obrisiIgraca(ArrayList<String[]> lista, String imeIgraca){
		if(lista == null || lista.isEmpty()) {
			return null;
		}
		for(String[] a : lista) {
		for(int i=0;i<lista.size()-1;i++) {
			
			if(a[0].equalsIgnoreCase(imeIgraca.trim())) {
				lista.remove(a);
			}
		}
	}
		return lista;
	}
	
	public void pokreniRundu(ArrayList<String[]> lista) {
		if(lista == null || lista.isEmpty()) {
			System.out.println("Lista je prazna");
		}
		
		Random random = new Random();
		
		int indeks1 = random.nextInt(lista.size());
		int indeks2 = random.nextInt(lista.size());
		
		while(indeks1 == indeks2) {
			indeks2=random.nextInt(lista.size());
		}
		
		String[] igrac1 = lista.get(indeks1);
		String[] igrac2 = lista.get(indeks2);
		
		System.out.println("Par igraca u ovoj rundi je:"+igrac1[0].trim()+" i "+igrac2[0].trim());
		
		int bodovi1 = Integer.parseInt(igrac1[1]);
		int bodovi2 = Integer.parseInt(igrac2[1]);
		
		int max=0;
		if(bodovi1>bodovi2) {
			max=bodovi1;
		}
		else {
			max = bodovi2;
		}
		
		int vjerovatnoca = random.nextInt(100)+1;
		
		if(vjerovatnoca<=60) {
			if(max==bodovi1) {
				System.out.println("Pobjednik je igrac "+igrac1[0]);
			}
			else {
				System.out.println("Pobjednik je igrac "+igrac2[0]);
			}
		}
		else {
			if(max==bodovi2) {
				System.out.println("Pobjednik je igrac "+igrac1[0]);
			}
			else {
				System.out.println("Pobjednik je igrac "+igrac2[0]);
			}
		}
		
		this.brojRundi++;
		
	}
	
	public String prikaziNajboljegIgraca (ArrayList<String[]> lista) {
		if(lista== null || lista.isEmpty()) {
			return "Lista je prazna";
		}
		int max = 0;
		String imeMax = null;
		for(String[] a : lista) {
			int bodovi = Integer.parseInt(a[1].trim());
			if(bodovi>max){
				max=bodovi;
				imeMax = a[0];
			}
		}
		return "Igrac koji je na putu da osvoji turnir je"+imeMax;
	}
	

}
