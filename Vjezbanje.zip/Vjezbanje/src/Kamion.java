
public class Kamion extends Vozilo {
	private int nosivost;
	
	public Kamion() {
		this.setMarka(null);
		this.setModel(null);
		this.setKubikaza(0);
		this.setGodiste(0);
		nosivost = 0;
	}

	public Kamion(String marka, String model, int kubikaza, int godiste, int nosivost) {
		super(marka, model, kubikaza, godiste);
		this.nosivost = nosivost;
	}

	public int getNosivost() {
		return nosivost;
	}

	public void setNosivost(int nosivost) {
		if(nosivost>=0)
		this.nosivost = nosivost;
	}

	@Override
	public String toString() {
		return "Kamion - nosivosti: " + nosivost + ", marka:" + getMarka() + ", model:" + getModel();
	}
	
	@Override 
	
	public float iznosRegistracije() {
		float iznosK = (this.getKubikaza()/10 + (2026-this.getGodiste())*10)*Vozilo.getOsnovicaZaRegistraciju()+30*nosivost;
		return iznosK;
	}
	

}
