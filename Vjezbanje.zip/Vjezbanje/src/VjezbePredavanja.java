import java.util.Scanner;

public class VjezbePredavanja {
	
	// Prve vjezbe
	/*
	public static void main(String[] args) {
		Scanner unos = new Scanner(System.in);
		int a,b,c;
		int brPoz=0;
		int brNeg=0;
		System.out.println("Unesite tri broja");
		a = unos.nextInt();
		b = unos.nextInt();
		c = unos.nextInt();
		
		if(a>=0) {
			brPoz++;
		}
		else if(a<0) {
			brNeg++;
		}
		
		if(b>=0) {
			brPoz++;
		}
		else if(b<0) {
			brNeg++;
		}
		
		if(c>=0) {
			brPoz++;
		}
		else if(c<0) {
			brNeg++;
		}
		System.out.println("Ima "+brPoz+" pozitivnih i "+brNeg+" negativnih brojeva");
		
	}
	*/
	
	// Druge vjezbe
	// Zadatak 1
	/*
	public static void main(String[] args) {
		Scanner unos = new Scanner(System.in);
		System.out.println("Unesite prirodan broj");
		int n = unos.nextInt();
		
		if(n<0) {
			n=n*(-1);
		}
		
		System.out.println("Apsolutna vrijednost ovog broja je "+n);
	}
	*/
	
	// Drugi zadatak
	
	/*
	public static void main(String[] args) {
		Scanner unos = new Scanner(System.in);
		System.out.println("Unesite broj");
		int x = unos.nextInt();
		double f = 0.0;
		if(x<1) {
			f = x*x;
		}
		else if(x>=5) {
			f=(x*x*x -1)/5;
		}
		else {
			f = 2-x;
		}
		
		System.out.println("Vrijednost funkcije je "+f);
	}
	*/
	
	// Treci zadatak faktorijel
	/*
	public static void main(String[] args) {
		Scanner unos = new Scanner(System.in);
		System.out.println("Unesite broj");
		int n = unos.nextInt();
		int f = 1;
		
		while(n>0) {
			f=f*n;
			n=n-1;
		}
		
		System.out.println("Faktorijel ovog broja je "+f);
	}
	*/
	
	// Cetvrti zadatak
	public static void main(String[] args) {
		Scanner unos = new Scanner(System.in);
		System.out.println("Unesite broj");
		int n = unos.nextInt();
		int najveca = 0;
		int najmanja = n%10;
		int temp = n;
		
		while(temp>0) {
			najveca=temp%10;
			temp=temp/10;
		}
		
		if(najveca==najmanja) {
			System.out.println("Cifre najvece i najmanje tezine su jednake");
		}
		else {
			System.out.println("Cifre najvece i najmanje tezine nisu jednake");
		}
	}
	

}
