
public class Pravougaonik {
	private int x;
	private int y;
	private int width;
	private int height;
	
	public Pravougaonik(int x, int y, int width, int height) {
		this.x = x;
		this.y = y;
		this.width = width;
		this.height = height;
	}
	public int getX() {
		return x;
	}
	public void setX(int x) {
		this.x = x;
	}
	public int getY() {
		return y;
	}
	public void setY(int y) {
		this.y = y;
	}
	public int getWidth() {
		return width;
	}
	public void setWidth(int width) {
		if(width>0)
		this.width = width;
	}
	public int getHeight() {
		return height;
	}
	public void setHeight(int height) {
		if(height>0)
		this.height = height;
	}
	
	public boolean sadrzi(int tx, int ty) {
		if((tx>=x && tx<=x+width) && (ty>=y && ty<=y+height))
				return true;
		else 
			return false;
	}
	
	public void ispisi() {
		System.out.println("Duzina pravougaonika je"+this.width+" a sirina je "+this.height);
	}

}
