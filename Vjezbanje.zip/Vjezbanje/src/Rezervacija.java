import java.util.ArrayList;
import java.time.LocalDate;;


public class Rezervacija {
	private String sala;
	private LocalDate datum;
	private int pocetakMin;
	private int krajMin;
	private String predmet;
	private String nosilac;
	
	public Rezervacija(String sala, LocalDate datum, int pocetakMin, int krajMin, String predmet, String nosilac) {
		this.sala = sala;
		this.datum = datum;
		this.pocetakMin = pocetakMin;
		this.krajMin = krajMin;
		this.predmet = predmet;
		this.nosilac = nosilac;
	}

	public String getSala() {
		return sala;
	}

	public void setSala(String sala) {
		if(sala!=null)
		this.sala = sala;
	}

	public LocalDate getDatum() {
		return datum;
	}

	public void setDatum(LocalDate datum) {
		this.datum = datum;
	}

	public int getPocetakMin() {
		return pocetakMin;
	}

	public void setPocetakMin(int pocetakMin) {
		if(pocetakMin>0)
		this.pocetakMin = pocetakMin;
	}

	public int getKrajMin() {
		return krajMin;
	}

	public void setKrajMin(int krajMin) {
		if(krajMin>0)
		this.krajMin = krajMin;
	}

	public String getPredmet() {
		return predmet;
	}

	public void setPredmet(String predmet) {
		if(predmet!=null)
		this.predmet = predmet;
	}

	public String getNosilac() {
		return nosilac;
	}

	public void setNosilac(String nosilac) {
		if(nosilac!=null)
		this.nosilac = nosilac;
	}
	
	public static ArrayList<Rezervacija> preklapanje (ArrayList<Rezervacija> lista, String sala, LocalDate datum){
		if(lista== null || lista.isEmpty()) {
			return null;
		}
		ArrayList<Rezervacija> problem = new ArrayList<>();
		for(Rezervacija a:lista) {
			if(a.getSala().equals(sala) && a.getDatum().equals(datum)) {
				problem.add(a);
			}
		}
		
		return problem;
	}
	
	public static ArrayList<Rezervacija> zauzeca (ArrayList<Rezervacija> lista, String sala, LocalDate datum){
		if(lista== null || lista.isEmpty()) {
			return null;
		}
		ArrayList<Rezervacija> problem = new ArrayList<>();
		for(Rezervacija a:lista) {
			if(a.getSala().equals(sala) && a.getDatum().equals(datum)) {
				problem.add(a);
			}
		}
		ArrayList<Rezervacija> preklapanja = new ArrayList<>();
		for(int i=0;i<problem.size();i++) {
			for(int j=i+1; j<problem.size();j++) {
				Rezervacija r1 = problem.get(i);
				Rezervacija r2 = problem.get(j);
				
				if(r1.getPocetakMin()<=r2.getKrajMin() && r2.getPocetakMin()<=r1.getKrajMin())
					if(!preklapanja.contains(r1)) {
						preklapanja.add(r1);
					}
				if(!preklapanja.contains(r2)) {
						preklapanja.add(r2);
					}
			}
			
		}
		return preklapanja;
	}
	
	

}
