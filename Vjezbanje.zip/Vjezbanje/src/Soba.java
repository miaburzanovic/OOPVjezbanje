
public class Soba {
	private int trenTemp;
	private int ciljTemp;
	
	public Soba(int trenTemp, int ciljTemp) {
		this.trenTemp = trenTemp;
		this.ciljTemp = ciljTemp;
	}
	public int getTrenTemp() {
		return trenTemp;
	}
	public void setTrenTemp(int trenTemp) {
		this.trenTemp = trenTemp;
	}
	public int getCiljTemp() {
		return ciljTemp;
	}
	public void setCiljTemp(int ciljTemp) {
		this.ciljTemp = ciljTemp;
	}
	
}
